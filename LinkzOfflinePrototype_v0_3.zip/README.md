# LinkzOfflinePrototype v0.3

UI rendering fix.

本版本重做文字容器：
- 所有文字使用 wrap_content
- 不再使用固定高度 TextView
- 不再使用 Android 原生 Button 作為按鈕
- 改用 TextView + GradientDrawable
- 關閉父容器 clipChildren / clipToPadding
- 修正換行
- versionCode 3 / versionName 0.3

測試流程：
啟動 → 主界面 → 農場 → 關卡選擇 → 選擇數碼寶貝 → 戰鬥
