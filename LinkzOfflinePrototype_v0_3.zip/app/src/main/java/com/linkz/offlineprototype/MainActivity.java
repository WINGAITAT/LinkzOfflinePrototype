package com.linkz.offlineprototype;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private FrameLayout screen;
    private final int BG = Color.rgb(8, 15, 28);
    private final int PANEL = Color.rgb(34, 55, 91);

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeText(String value, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(true);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setBackgroundColor(Color.TRANSPARENT);
        t.setMaxLines(4);
        t.setEllipsize(null);
        return t;
    }

    private View makeButton(String label, final View.OnClickListener listener) {
        TextView b = makeText(label, 18, false);
        b.setGravity(Gravity.CENTER);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(PANEL);
        shape.setCornerRadius(dp(14));
        b.setBackground(shape);
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(listener);
        b.setMinimumHeight(dp(56));
        return b;
    }

    private void begin(String title) {
        screen = new FrameLayout(this);
        screen.setBackgroundColor(BG);
        screen.setClipChildren(false);
        screen.setClipToPadding(false);
        setContentView(screen);

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        column.setClipChildren(false);
        column.setClipToPadding(false);
        column.setPadding(dp(20), dp(24), dp(20), dp(24));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        cp.leftMargin = dp(20);
        cp.rightMargin = dp(20);
        screen.addView(column, cp);

        TextView titleView = makeText(title, 28, true);
        titleView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.bottomMargin = dp(14);
        column.addView(titleView, tp);
    }

    private void info(String value) {
        TextView t = makeText(value, 18, false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(10);
        t.setGravity(Gravity.CENTER);
        // Add to the centered column.
        ((LinearLayout)screen.getChildAt(0)).addView(t, p);
    }

    private void addButton(String label, View.OnClickListener listener) {
        LinearLayout column = (LinearLayout) screen.getChildAt(0);
        View b = makeButton(label, listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                dp(520), ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(6);
        p.bottomMargin = dp(6);
        column.addView(b, p);
    }

    private void showMain() {
        begin("LINKZ OFFLINE  •  主界面");
        info("離線 Prototype v0.3");
        info("不連線、不登入");
        addButton("進入農場", v -> showFarm());
        addButton("關卡選擇", v -> showStages());
    }

    private void showFarm() {
        begin("農場");
        info("這裡先作為離線農場測試入口。");
        info("之後可接入 Linkz 真實資源。");
        addButton("前往關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }

    private void showStages() {
        begin("關卡選擇");
        addButton("第一關  •  草原測試", v -> showDigimon());
        addButton("第二關  •  城市測試", v -> showDigimon());
        addButton("返回主界面", v -> showMain());
    }

    private void showDigimon() {
        begin("選擇數碼寶貝");
        addButton("Agumon  •  選擇", v -> showBattle("Agumon"));
        addButton("Gabumon  •  選擇", v -> showBattle("Gabumon"));
        addButton("Patamon  •  選擇", v -> showBattle("Patamon"));
        addButton("返回關卡選擇", v -> showStages());
    }

    private void showBattle(String player) {
        begin("戰鬥");
        info("我方： " + player);
        info("VS");
        info("敵方： Test Digimon");
        info("HP  100 / 100");
        addButton("普通攻擊  →  -20 HP", v ->
                Toast.makeText(this, "攻擊成功！第一版戰鬥流程測試。", Toast.LENGTH_SHORT).show());
        addButton("返回關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setNavigationBarColor(Color.BLACK);
        showMain();
    }
}
