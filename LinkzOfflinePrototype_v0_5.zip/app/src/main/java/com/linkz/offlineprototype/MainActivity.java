package com.linkz.offlineprototype;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;

public class MainActivity extends Activity {
    private GameView game;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        game = new GameView();
        setContentView(game);
    }

    private class GameView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint buttonPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        int page = 0; // 0 main, 1 farm, 2 stages, 3 digimon, 4 battle
        String player = "";

        float d;

        GameView() {
            super(MainActivity.this);
            d = getResources().getDisplayMetrics().density;
            p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            buttonPaint.setColor(Color.rgb(35,55,90));
            setBackgroundColor(Color.rgb(8,15,28));
            setFocusable(true);
        }

        float dp(float v) { return v * d; }

        void centerText(Canvas c, String s, float x, float baseline, float sp, boolean bold) {
            p.setColor(Color.WHITE);
            p.setTextSize(dp(sp));
            p.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
            p.setTextAlign(Paint.Align.CENTER);
            p.setStyle(Paint.Style.FILL);
            // Baseline is deliberately kept well away from the top/bottom edges.
            c.drawText(s, x, baseline, p);
        }

        void roundedButton(Canvas c, float l, float t, float r, float b, String label) {
            buttonPaint.setStyle(Paint.Style.FILL);
            buttonPaint.setColor(Color.rgb(35,55,90));
            c.drawRoundRect(l,t,r,b,dp(14),dp(14),buttonPaint);
            centerText(c, label, (l+r)/2f, t + (b-t)/2f - (p.ascent()+p.descent())/2f,
                    18, false);
        }

        void button(Canvas c, int index, String label) {
            float w = getWidth();
            float bw = Math.min(dp(520), w - dp(100));
            float h = buttonHeight();
            float gap = buttonGap();
            float x = (w-bw)/2f;

            // Buttons are placed in a dedicated lower area so they never cover text.
            float first = buttonAreaTop();
            float top = first + index*(h+gap);
            roundedButton(c,x,top,x+bw,top+h,label);
        }

        float buttonHeight() {
            if (countButtons >= 4) return dp(44);
            if (countButtons == 3) return dp(50);
            return dp(58);
        }

        float buttonGap() {
            if (countButtons >= 4) return dp(8);
            if (countButtons == 3) return dp(10);
            return dp(18);
        }

        float buttonAreaTop() {
            float h = buttonHeight();
            float gap = buttonGap();
            float total = countButtons * h + (countButtons - 1) * gap;
            float preferred;
            if (page == 0) preferred = dp(190);
            else if (countButtons >= 4) preferred = dp(125);
            else if (countButtons == 3) preferred = dp(145);
            else preferred = dp(205);
            float maxTop = getHeight() - total - dp(18);
            return Math.max(dp(95), Math.min(preferred, maxTop));
        }

        int countButtons = 2;

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight(), cx=w/2f;

            if(page==0) {
                centerText(c,"LINKZ OFFLINE",cx,dp(72),30,true);
                centerText(c,"主界面",cx,dp(112),22,false);
                centerText(c,"上次登入：離線模式",cx,dp(158),18,false);
                centerText(c,"版本：1.0.0  •  Offline Prototype",cx,dp(205),17,false);
                countButtons=2;
                button(c,0,"進入農場");
                button(c,1,"關卡選擇");
            } else if(page==1) {
                centerText(c,"農場",cx,dp(90),30,true);
                centerText(c,"這裡先作為離線農場測試入口。",cx,dp(145),18,false);
                centerText(c,"之後可接入 Linkz 真實資源。",cx,dp(180),18,false);
                countButtons=2;
                button(c,0,"前往關卡選擇");
                button(c,1,"返回主界面");
            } else if(page==2) {
                centerText(c,"關卡選擇",cx,dp(90),30,true);
                countButtons=3;
                button(c,0,"第一關  •  草原測試");
                button(c,1,"第二關  •  城市測試");
                button(c,2,"返回主界面");
            } else if(page==3) {
                centerText(c,"選擇數碼寶貝",cx,dp(90),30,true);
                countButtons=4;
                button(c,0,"Agumon  •  選擇");
                button(c,1,"Gabumon  •  選擇");
                button(c,2,"Patamon  •  選擇");
                button(c,3,"返回關卡選擇");
            } else {
                centerText(c,"戰鬥",cx,dp(80),30,true);
                centerText(c,"我方： "+player,cx,dp(135),20,false);
                centerText(c,"VS",cx,dp(175),20,true);
                centerText(c,"敵方： Test Digimon",cx,dp(215),20,false);
                centerText(c,"HP  100 / 100",cx,dp(255),20,false);
                countButtons=3;
                button(c,0,"普通攻擊  →  -20 HP");
                button(c,1,"返回關卡選擇");
                button(c,2,"返回主界面");
            }
        }

        String currentLabel(int i) {
            if(page==0) return i==0 ? "進入農場" : "關卡選擇";
            if(page==1) return i==0 ? "前往關卡選擇" : "返回主界面";
            if(page==2) return i==0 ? "第一關  •  草原測試" : i==1 ? "第二關  •  城市測試" : "返回主界面";
            if(page==3) return i==0 ? "Agumon  •  選擇" : i==1 ? "Gabumon  •  選擇" : i==2 ? "Patamon  •  選擇" : "返回關卡選擇";
            return i==0 ? "普通攻擊  →  -20 HP" : i==1 ? "返回關卡選擇" : "返回主界面";
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float w=getWidth();
            float bw=Math.min(dp(520),w-dp(100));
            float bh=buttonHeight(), gap=buttonGap();
            float x=(w-bw)/2f;
            float first=buttonAreaTop();
            float tx=e.getX(), ty=e.getY();
            for(int i=0;i<countButtons;i++){
                float top=first+i*(bh+gap);
                if(tx>=x && tx<=x+bw && ty>=top && ty<=top+bh){
                    handle(i);
                    return true;
                }
            }
            return true;
        }

        void handle(int i) {
            if(page==0) { if(i==0) page=1; else page=2; }
            else if(page==1) { if(i==0) page=2; else page=0; }
            else if(page==2) { if(i<2) page=3; else page=0; }
            else if(page==3) {
                if(i<3) { player = i==0?"Agumon":i==1?"Gabumon":"Patamon"; page=4; }
                else page=2;
            } else {
                if(i==0) android.widget.Toast.makeText(MainActivity.this,"攻擊成功！第一版戰鬥流程測試。",android.widget.Toast.LENGTH_SHORT).show();
                else if(i==1) page=2;
                else page=0;
            }
            invalidate();
        }
    }
}
