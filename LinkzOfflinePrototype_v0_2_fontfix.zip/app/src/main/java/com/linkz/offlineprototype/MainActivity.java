package com.linkz.offlineprototype;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, float sizeSp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sizeSp);
        t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(true);
        t.setPadding(dp(8), dp(4), dp(8), dp(4));
        t.setLineSpacing(0, 1.0f);
        t.setSingleLine(false);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(true);
        b.setPadding(dp(12), dp(4), dp(12), dp(4));
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setMinimumHeight(0);
        b.setMinimumWidth(0);
        b.setSingleLine(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(35, 55, 90));
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        return b;
    }

    private void base(String screen) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(20), dp(24), dp(20));
        root.setBackgroundColor(Color.rgb(10, 16, 30));
        setContentView(root);

        TextView title = text(screen, 28);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        LinearLayout.LayoutParams tp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        tp.setMargins(0, dp(4), 0, dp(10));
        root.addView(title, tp);
    }

    private void addText(String s, float sizeSp, int heightDp) {
        TextView t = text(s, sizeSp);
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp));
        p.setMargins(0, 0, 0, dp(8));
        root.addView(t, p);
    }

    private void addButton(String label, View.OnClickListener listener) {
        Button b = button(label);
        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(dp(520), dp(60));
        p.setMargins(0, dp(7), 0, dp(7));
        root.addView(b, p);
        b.setOnClickListener(listener);
    }

    private void showMain() {
        base("LINKZ OFFLINE  •  主界面");
        addText("離線 Prototype v0.2\n不連線、不登入", 18, 82);
        addButton("進入農場", v -> showFarm());
        addButton("關卡選擇", v -> showStages());
    }

    private void showFarm() {
        base("農場");
        addText("這裡先作為離線農場測試入口。\n之後可接入 Linkz 真實資源。", 18, 82);
        addButton("前往關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }

    private void showStages() {
        base("關卡選擇");
        addButton("第一關  •  草原測試", v -> showDigimon());
        addButton("第二關  •  城市測試", v -> showDigimon());
        addButton("返回主界面", v -> showMain());
    }

    private void showDigimon() {
        base("選擇數碼寶貝");
        addButton("Agumon  •  選擇", v -> showBattle("Agumon"));
        addButton("Gabumon  •  選擇", v -> showBattle("Gabumon"));
        addButton("Patamon  •  選擇", v -> showBattle("Patamon"));
        addButton("返回關卡選擇", v -> showStages());
    }

    private void showBattle(String player) {
        base("戰鬥");
        addText("我方： " + player + "\nVS\n敵方： Test Digimon\n\nHP  100 / 100", 20, 150);
        addButton("普通攻擊  →  -20 HP", v ->
                Toast.makeText(this, "攻擊成功！這是第一版戰鬥流程測試。", Toast.LENGTH_SHORT).show());
        addButton("返回關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }
}
