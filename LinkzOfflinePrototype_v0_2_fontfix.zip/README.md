# LinkzOfflinePrototype v0.2

離線 Android Prototype。

流程：
啟動 → 主界面 → 農場 → 關卡選擇 → 選擇數碼寶貝 → 戰鬥

本版本先修正 Android 文字顯示問題：
- 不再使用固定像素高度造成文字裁切
- 明確使用 Android sans-serif 字體
- 增加字體上下留白
- 按鈕改為較安全的 60dp 高度
- 修正原本把 `\n` 顯示成文字的問題

尚未加入 Linkz 真實模型、貼圖、音效或原始 AssetBundle。
