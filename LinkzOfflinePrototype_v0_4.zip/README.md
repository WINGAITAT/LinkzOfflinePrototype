# LinkzOfflinePrototype v0.4

本版本針對手機實際畫面出現的文字裁切問題，將 UI 從 Android TextView/Button 完全改為單一自訂 Canvas View。

目的：
- 避免 TextView / Button 的內部字體裁切
- 避免固定高度布局
- 直接由 Canvas 在安全 baseline 位置繪製文字
- 所有按鈕也由 Canvas 繪製
- 保持橫屏
- 保持原本離線流程

流程：
啟動 → 主界面 → 農場 → 關卡選擇 → 選擇數碼寶貝 → 戰鬥

尚未加入 Linkz 真實模型、貼圖、音效或 AssetBundle。
