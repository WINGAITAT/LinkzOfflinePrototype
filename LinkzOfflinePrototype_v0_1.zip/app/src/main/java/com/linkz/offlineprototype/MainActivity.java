package com.linkz.offlineprototype;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView title;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showMain();
    }

    TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); t.setPadding(18,12,18,12);
        return t;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(18); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(35,55,90)); bg.setCornerRadius(24);
        b.setBackground(bg);
        return b;
    }

    void base(String screen) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40,30,40,30);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(10,16,30));
        title = text(screen, 30);
        root.addView(title, new LinearLayout.LayoutParams(-1,80));
        setContentView(root);
    }

    void addButton(String label, View.OnClickListener l) {
        Button b = button(label);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(520,80);
        p.setMargins(0,12,0,12);
        root.addView(b,p); b.setOnClickListener(l);
    }

    void showMain() {
        base("LINKZ OFFLINE  •  主界面");
        root.addView(text("離線 Prototype v0.1\\n不連線、不登入",18),
                new LinearLayout.LayoutParams(-1,120));
        addButton("進入農場", v -> showFarm());
        addButton("關卡選擇", v -> showStages());
    }

    void showFarm() {
        base("農場");
        root.addView(text("這裡先作為離線農場測試入口。\\n之後可接入 Linkz 真實資源。",18),
                new LinearLayout.LayoutParams(-1,120));
        addButton("前往關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }

    void showStages() {
        base("關卡選擇");
        addButton("第一關  •  草原測試", v -> showDigimon());
        addButton("第二關  •  城市測試", v -> showDigimon());
        addButton("返回主界面", v -> showMain());
    }

    void showDigimon() {
        base("選擇數碼寶貝");
        addButton("Agumon  •  選擇", v -> showBattle("Agumon"));
        addButton("Gabumon  •  選擇", v -> showBattle("Gabumon"));
        addButton("Patamon  •  選擇", v -> showBattle("Patamon"));
        addButton("返回關卡選擇", v -> showStages());
    }

    void showBattle(String player) {
        base("戰鬥");
        root.addView(text("我方： " + player + "\\nVS\\n敵方： Test Digimon\\n\\nHP  100 / 100",20),
                new LinearLayout.LayoutParams(-1,180));
        addButton("普通攻擊  →  -20 HP", v ->
                Toast.makeText(this,"攻擊成功！這是第一版戰鬥流程測試。",Toast.LENGTH_SHORT).show());
        addButton("返回關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }
}
