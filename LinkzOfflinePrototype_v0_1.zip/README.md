# Linkz Offline Prototype v0.1

目的：先驗證 Android 手機上的最小離線流程。

流程：
啟動 → 主界面 → 農場 → 關卡選擇 → 選擇數碼寶貝 → 戰鬥

目前版本不包含：
- 網路
- 登入
- 伺服器
- 原版 Linkz 資源
- 完整戰鬥系統

下一階段可逐步替換成從 Linkz APK 分析得到的真實資源與邏輯。

## 電腦編譯
使用 Android Studio 開啟此專案，等待 Gradle Sync 完成後：
Build → Build APK(s)

生成的 APK 通常位於：
app/build/outputs/apk/debug/app-debug.apk
