package com.linkz.offlineprototype;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView title;

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView text(String s, float sizeSp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sizeSp);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        t.setIncludeFontPadding(true);
        return t;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(52));
        b.setPadding(dp(16), dp(8), dp(16), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(35,55,90));
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        return b;
    }

    void base(String screen) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(10,16,30));

        title = text(screen, 28);
        root.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        setContentView(root);
    }

    void addButton(String label, View.OnClickListener l) {
        Button b = button(label);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0, dp(6), 0, dp(6));
        root.addView(b, p);
        b.setOnClickListener(l);
    }

    void showMain() {
        base("LINKZ OFFLINE  •  主界面");
        root.addView(text("離線 Prototype v0.2\n不連線、不登入", 18),
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                ));
        addButton("進入農場", v -> showFarm());
        addButton("關卡選擇", v -> showStages());
    }

    void showFarm() {
        base("農場");
        root.addView(text("這裡先作為離線農場測試入口。\n之後可接入 Linkz 真實資源。", 18),
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                ));
        addButton("前往關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }

    void showStages() {
        base("關卡選擇");
        addButton("第一關  •  草原測試", v -> showDigimon());
        addButton("第二關  •  城市測試", v -> showDigimon());
        addButton("返回主界面", v -> showMain());
    }

    void showDigimon() {
        base("選擇數碼寶貝");
        addButton("Agumon  •  選擇", v -> showBattle("Agumon"));
        addButton("Gabumon  •  選擇", v -> showBattle("Gabumon"));
        addButton("Patamon  •  選擇", v -> showBattle("Patamon"));
        addButton("返回關卡選擇", v -> showStages());
    }

    void showBattle(String player) {
        base("戰鬥");
        root.addView(text("我方： " + player + "\nVS\n敵方： Test Digimon\n\nHP  100 / 100", 20),
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                ));
        addButton("普通攻擊  →  -20 HP", v ->
                Toast.makeText(this, "攻擊成功！這是第一版戰鬥流程測試。",
                        Toast.LENGTH_SHORT).show());
        addButton("返回關卡選擇", v -> showStages());
        addButton("返回主界面", v -> showMain());
    }
}
